#ifndef PROJECT7_QUESTION1_H
#define PROJECT7_QUESTION1_H
int n;
#endif