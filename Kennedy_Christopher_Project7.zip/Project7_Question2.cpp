// Introductory lines
#include <iostream>
#include <vector>
using namespace std;
#include "Project7_Question2.h"

void print_vector(std::vector<int> v) {
    for (int i = 0; i < v.size(); ++i) {
        std::cout << v[i] << " ";
    }
    std::cout << std::endl;
}