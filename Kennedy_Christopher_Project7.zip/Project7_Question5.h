#ifndef PASCAL_H
#define PASCAL_H

#include <iostream>  // For input/output operations
#include <vector>    // For using the vector data structure

using namespace std;

void printPascalsTriangle(int n);

#endif // PASCAL_H