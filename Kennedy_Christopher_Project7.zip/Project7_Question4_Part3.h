#ifndef PRIME_FACTORIZATION_H
#define PRIME_FACTORIZATION_H

#include <vector>

// Function to find the prime factorization of a number
std::vector<int> prime_factorize(int n);

void test_prime_factorize();

#endif // PRIME_FACTORIZATION_H