#ifndef FACTORIZE_H
#define FACTORIZE_H

#include <vector>

// Function to find all factors of a given number
std::vector<int> factorize(int n);

// Helper function to print vectors (useful for testing)
void print_vector(const std::vector<int>& vec);

#endif // FACTORIZE_H