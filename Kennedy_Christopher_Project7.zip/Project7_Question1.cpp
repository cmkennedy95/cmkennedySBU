// Introductory lines
#include <iostream>
#include "Project7_Question1.h"
using namespace std;

int main() {

    // Prompt user for input
    cout << "Enter a number: ";
    cin >> n;

    // Switch statement
    switch (n) {
    case -1:
        cout << "negative one" << endl;
        break;
    case 0:
        cout << "zero" << endl;
        break;
    case 1:
        cout << "positive one" << endl;
        break;
    default:
        cout << "other value" << endl;
        break;
    }
    
    return 0;
}