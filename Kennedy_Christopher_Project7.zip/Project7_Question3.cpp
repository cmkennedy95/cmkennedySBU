// Introductory lines
#include <iostream>
#include "Project7_Question3.h"

int main() {
    // Initialize the first two Fibonacci numbers
    int a = 1, b = 2;

    // While loop to generate Fibonacci numbers until the value exceeds 4,000,000
    while (a <= 4000000) {
        std::cout << a << std::endl;
        
        // Generate the next Fibonacci number
        int next = a + b;
        a = b;
        b = next;
    }

    return 0;
}