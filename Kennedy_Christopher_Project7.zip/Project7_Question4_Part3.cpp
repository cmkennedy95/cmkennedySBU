// Introductory lines
#include <iostream>
#include <vector>
#include <cmath>
#include "Project7_Question2.h"
#include "Project7_Question4_Part3.h"
using namespace std;

// Function to find prime factorization of n
std::vector<int> prime_factorize(int n) {
    std::vector<int> answer;
    
    // First, handle factor of 2
    while (n % 2 == 0) {
        answer.push_back(2);
        n /= 2;
    }
    
    // Now, check odd numbers from 3 to sqrt(n)
    for (int i = 3; i <= std::sqrt(n); i += 2) {
        while (n % i == 0) {
            answer.push_back(i);
            n /= i;
        }
    }
    
    // If n is still greater than 2, then n itself is prime
    if (n > 2) {
        answer.push_back(n);
    }
    
    return answer;
}

// Function to test prime_factorize with given test cases
void test_prime_factorize() {
    print_vector(prime_factorize(2));    // Should output: 2
    print_vector(prime_factorize(72));   // Should output: 2 2 2 3 3
    print_vector(prime_factorize(196));  // Should output: 2 2 7 7
}

int main() {
    test_prime_factorize();
    return 0;
}