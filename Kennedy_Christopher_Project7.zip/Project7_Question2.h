#include <iostream>  // for std::cout
#include <vector>    // for std::vector

void print_vector(std::vector<int> v);