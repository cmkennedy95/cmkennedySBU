// Introductory lines
#include <iostream>
#include <vector>
#include "Project7_Question5.h"

using namespace std;

// Function to print the first n rows of Pascal's Triangle using iteration
void printPascalsTriangle(int n) {
    // We will use a 2D vector to store the rows of Pascal's Triangle
    vector<vector<int>> triangle(n);

    // Loop through each row of Pascal's Triangle
    for (int i = 0; i < n; ++i) {
        // Resize the current row to have i + 1 elements (since the i-th row has i + 1 elements)
        triangle[i].resize(i + 1);

        // Set the first and last element of the row to 1
        triangle[i][0] = triangle[i][i] = 1;

        // Fill in the middle values of the row (if any) based on the previous row
        for (int j = 1; j < i; ++j) {
            // Each element is the sum of the two elements directly above it from the previous row
            triangle[i][j] = triangle[i-1][j-1] + triangle[i-1][j];
        }
    }

    // Print the triangle
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j <= i; ++j) {
            cout << triangle[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int n;
    cout << "Enter the number of rows: ";
    cin >> n;

    // Print Pascal's Triangle with n rows
    printPascalsTriangle(n);

    return 0;
}