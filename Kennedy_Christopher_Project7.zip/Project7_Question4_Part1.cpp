// Introductory lines
#include <iostream>
#include "Project7_Question4_Part1.h"

bool isprime(int n) {
    bool result = true; // Assume the number is prime initially

    if (n <= 1) {
        result = false; // Numbers less than or equal to 1 are not prime
    } else {
        for (int i = 2; i * i <= n; ++i) {
            if (n % i == 0) {
                result = false; // If a divisor is found, it's not prime
                break;
            }
        }
    }

    return result;
}

void test_isprime() {
    std::cout << "isprime(2) = " << isprime(2) << '\n';
    std::cout << "isprime(10) = " << isprime(10) << '\n';
    std::cout << "isprime(17) = " << isprime(17) << '\n';
}

int main() {
    test_isprime();
    return 0;
}