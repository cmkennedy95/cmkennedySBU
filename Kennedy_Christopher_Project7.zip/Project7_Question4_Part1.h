#ifndef ISPRIME_H
#define ISPRIME_H

// Function declaration
bool isprime(int n);

#endif // ISPRIME_H