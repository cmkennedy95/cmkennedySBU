// Introductory lines
#include <iostream>
#include <vector>
#include <cmath>
#include "Project7_Question2.h"
using namespace std;

std::vector<int> factorize(int n) {
    std::vector<int> answer;
    for (int i = 1; i <= std::sqrt(n); ++i) {
        if (n % i == 0) {
            answer.push_back(i);
            if (i != n / i) {
                answer.push_back(n / i);  // Add the complementary factor
            }
        }
    }
    return answer;
}

void test_factorize() {
    print_vector(factorize(2));   // Expected: 1 2
    print_vector(factorize(72));  // Expected: 1 72 2 36 3 24 4 18 6 12 8 9
    print_vector(factorize(196)); // Expected: 1 196 2 98 4 49 7 28 14 14
}

int main() {
    test_factorize();
    return 0;
}